class SClock
{
  public:
    static void mhz();
};